Domain regested at REG.ru

Uses https://formspree.io/ for processing POST requests

Uses contact@potolki-trio.ru https://web12.beget.email/?_task=mail&_mbox=INBOX as mail inbox